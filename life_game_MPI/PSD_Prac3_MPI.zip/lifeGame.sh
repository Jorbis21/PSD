rm imagenFinal.bmp
make clean
make
mpiexec -np 6 lifeGame 200 200 100 auto imagenFinal.bmp dynamic 10
