mpicc -o lifeGame *.c -I/usr/local/include/SDL2 -L/usr/local/lib/ -lSDL2
