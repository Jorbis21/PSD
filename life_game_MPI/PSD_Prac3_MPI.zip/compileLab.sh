mpicc -o lifeGame *.c -I/usr/local/sdl2/include/SDL2 -L/usr/local/sdl2/lib/ -lSDL2
